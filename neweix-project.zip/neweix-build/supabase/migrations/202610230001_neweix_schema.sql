-- Review this migration before applying it to your production project.
create extension if not exists pgcrypto;
create type public.staff_role as enum ('admin','supreme');
create type public.order_status as enum ('pending','confirmed','packing','shipped','delivered','cancelled','returned');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.staff_roles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  role public.staff_role not null,
  granted_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  slug text not null unique,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  price_bdt integer not null check(price_bdt >= 0),
  compare_at_price_bdt integer check(compare_at_price_bdt is null or compare_at_price_bdt >= price_bdt),
  category_id uuid references public.categories(id) on delete set null,
  stock integer not null default 0 check(stock >= 0),
  active boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.product_media (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  media_type text not null check(media_type in ('image','youtube')),
  url text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique default ('NW-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,10))),
  user_id uuid references auth.users(id) on delete set null,
  customer_name text not null,
  customer_phone text not null,
  delivery_address text not null,
  status public.order_status not null default 'pending',
  payment_method text not null default 'cod' check(payment_method in ('cod','bkash','nagad','gateway')),
  payment_status text not null default 'unpaid' check(payment_status in ('unpaid','pending','paid','failed','refunded')),
  subtotal_bdt integer not null check(subtotal_bdt >= 0),
  delivery_fee_bdt integer not null default 0 check(delivery_fee_bdt >= 0),
  total_bdt integer not null check(total_bdt >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check(quantity > 0),
  unit_price_bdt integer not null check(unit_price_bdt >= 0),
  line_total_bdt integer not null check(line_total_bdt >= 0)
);
create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check(discount_type in ('fixed','percent')),
  discount_value integer not null check(discount_value > 0),
  active boolean not null default false,
  starts_at timestamptz,
  ends_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.delivery_settings (
  id uuid primary key default gen_random_uuid(),
  provider_name text not null,
  base_fee_bdt integer not null default 0 check(base_fee_bdt >= 0),
  active boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.audit_logs (
  id bigint generated always as identity primary key,
  actor_user_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
-- Enable RLS on all exposed tables.
alter table public.profiles enable row level security;
alter table public.staff_roles enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_media enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.coupons enable row level security;
alter table public.delivery_settings enable row level security;
alter table public.audit_logs enable row level security;
-- Public can read active catalogue only.
create policy "public read active categories" on public.categories for select to anon, authenticated using (active = true);
create policy "public read active products" on public.products for select to anon, authenticated using (active = true);
create policy "public read media for active products" on public.product_media for select to anon, authenticated using (exists(select 1 from public.products p where p.id=product_id and p.active=true));
-- Profiles: users only see and update their own profile.
create policy "read own profile" on public.profiles for select to authenticated using ((select auth.uid())=id);
create policy "insert own profile" on public.profiles for insert to authenticated with check ((select auth.uid())=id);
create policy "update own profile" on public.profiles for update to authenticated using ((select auth.uid())=id) with check ((select auth.uid())=id);
-- Orders are private to their owner; checkout must be implemented through a validated server-side function/API.
create policy "read own orders" on public.orders for select to authenticated using ((select auth.uid())=user_id);
create policy "read own order items" on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id=order_id and o.user_id=(select auth.uid())));
-- No client-side insert/update policies for orders, roles, coupons, delivery settings, or audit logs by design.
revoke all on public.staff_roles, public.audit_logs from anon, authenticated;
revoke insert, update, delete on public.orders, public.order_items, public.products, public.product_media, public.categories, public.coupons, public.delivery_settings from anon, authenticated;
grant select on public.categories, public.products, public.product_media to anon, authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select on public.orders, public.order_items to authenticated;
