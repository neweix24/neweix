export type Product = {id:string;name:string;price:number;category:string;description:string;image?:string;stock:number};
export const products:Product[] = [
{id:"classic-tshirt",name:"প্রিমিয়াম টি-শার্ট",price:650,category:"ফ্যাশন",description:"দৈনন্দিন ব্যবহারের জন্য আরামদায়ক প্রিমিয়াম টি-শার্ট।",stock:25},
{id:"classic-watch",name:"ক্লাসিক ওয়াচ",price:1850,category:"লাইফস্টাইল",description:"মিনিমাল ডিজাইনের স্টাইলিশ ঘড়ি।",stock:12},
{id:"wireless-earbuds",name:"ওয়্যারলেস ইয়ারবাডস",price:1450,category:"ইলেকট্রনিক্স",description:"দৈনন্দিন ব্যবহারের জন্য কমপ্যাক্ট ওয়্যারলেস ইয়ারবাডস।",stock:18},
{id:"everyday-backpack",name:"এভরিডে ব্যাকপ্যাক",price:1250,category:"অ্যাক্সেসরিজ",description:"কাজ, পড়াশোনা ও ভ্রমণের জন্য ব্যবহারিক ব্যাকপ্যাক।",stock:9},
{id:"travel-mug",name:"ট্রাভেল মগ",price:520,category:"লাইফস্টাইল",description:"বাইরে চলার পথে পানীয় সঙ্গে রাখার জন্য।",stock:20},
{id:"phone-stand",name:"ফোন স্ট্যান্ড",price:350,category:"অ্যাক্সেসরিজ",description:"ডেস্কে ফোন রাখার সহজ স্ট্যান্ড।",stock:30},
{id:"everyday-shirt",name:"ক্যাজুয়াল শার্ট",price:990,category:"ফ্যাশন",description:"স্মার্ট ক্যাজুয়াল লুকের জন্য।",stock:14},
{id:"desk-lamp",name:"ডেস্ক ল্যাম্প",price:1150,category:"হোম",description:"পড়াশোনা ও কাজের ডেস্কের জন্য ল্যাম্প।",stock:8}
];
export const money=(amount:number)=>`৳${amount.toLocaleString("en-BD")}`;
